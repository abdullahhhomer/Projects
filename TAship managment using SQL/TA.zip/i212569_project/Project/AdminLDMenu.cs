﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class AdminLDMenu : Form
    {
        public AdminLDMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddingLDMember addingLDMember = new AddingLDMember();
            this.Visible = false;
            addingLDMember.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewingLDMember viewingLDMember = new ViewingLDMember();
            this.Visible = false;
            viewingLDMember.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeletingLDMember deletingLDMember = new DeletingLDMember();
            this.Visible = false;
            deletingLDMember.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            adminMenu adminMenu = new adminMenu();
            this.Visible = false;
            adminMenu.Visible = true;
        }
    }
}
