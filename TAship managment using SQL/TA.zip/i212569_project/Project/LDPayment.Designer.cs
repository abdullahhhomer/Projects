﻿namespace Project
{
    partial class LDPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LDPayment));
            idbox = new TextBox();
            label6 = new Label();
            label1 = new Label();
            label2 = new Label();
            amtbox = new TextBox();
            button1 = new Button();
            label3 = new Label();
            id1box = new TextBox();
            button2 = new Button();
            paymentidbox = new TextBox();
            label4 = new Label();
            SuspendLayout();
            // 
            // idbox
            // 
            idbox.Location = new Point(270, 149);
            idbox.Name = "idbox";
            idbox.Size = new Size(198, 23);
            idbox.TabIndex = 23;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(119, 43);
            label6.Name = "label6";
            label6.Size = new Size(466, 47);
            label6.TabIndex = 22;
            label6.Text = "Enter the following Credentials";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(119, 144);
            label1.Name = "label1";
            label1.Size = new Size(101, 28);
            label1.TabIndex = 21;
            label1.Text = "Admin ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(119, 210);
            label2.Name = "label2";
            label2.Size = new Size(86, 28);
            label2.TabIndex = 24;
            label2.Text = "Amount";
            // 
            // amtbox
            // 
            amtbox.Location = new Point(270, 217);
            amtbox.Name = "amtbox";
            amtbox.Size = new Size(198, 23);
            amtbox.TabIndex = 25;
            // 
            // button1
            // 
            button1.Location = new Point(333, 246);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 26;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(119, 182);
            label3.Name = "label3";
            label3.Size = new Size(65, 28);
            label3.TabIndex = 27;
            label3.Text = "LD ID";
            label3.Click += label3_Click;
            // 
            // id1box
            // 
            id1box.Location = new Point(270, 182);
            id1box.Name = "id1box";
            id1box.Size = new Size(198, 23);
            id1box.TabIndex = 28;
            // 
            // button2
            // 
            button2.Location = new Point(307, 285);
            button2.Name = "button2";
            button2.Size = new Size(124, 23);
            button2.TabIndex = 29;
            button2.Text = "Back To List";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // paymentidbox
            // 
            paymentidbox.Location = new Point(270, 109);
            paymentidbox.Name = "paymentidbox";
            paymentidbox.Size = new Size(198, 23);
            paymentidbox.TabIndex = 30;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(119, 104);
            label4.Name = "label4";
            label4.Size = new Size(121, 28);
            label4.TabIndex = 31;
            label4.Text = "Payment ID";
            // 
            // LDPayment
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(paymentidbox);
            Controls.Add(button2);
            Controls.Add(id1box);
            Controls.Add(label3);
            Controls.Add(button1);
            Controls.Add(amtbox);
            Controls.Add(label2);
            Controls.Add(idbox);
            Controls.Add(label6);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "LDPayment";
            Text = "LD Payment";
            Load += LDPayment_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox idbox;
        private Label label6;
        private Label label1;
        private Label label2;
        private TextBox amtbox;
        private Button button1;
        private Label label3;
        private TextBox id1box;
        private Button button2;
        private TextBox paymentidbox;
        private Label label4;
    }
}