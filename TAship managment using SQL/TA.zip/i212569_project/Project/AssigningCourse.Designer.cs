﻿namespace Project
{
    partial class AssigningCourse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AssigningCourse));
            button2 = new Button();
            button1 = new Button();
            coursenamebox = new TextBox();
            studentidbox = new TextBox();
            label6 = new Label();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(323, 290);
            button2.Name = "button2";
            button2.Size = new Size(147, 23);
            button2.TabIndex = 47;
            button2.Text = "Back to List";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(356, 242);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 46;
            button1.Text = "Assign";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // coursenamebox
            // 
            coursenamebox.Location = new Point(291, 189);
            coursenamebox.Name = "coursenamebox";
            coursenamebox.Size = new Size(198, 23);
            coursenamebox.TabIndex = 45;
            // 
            // studentidbox
            // 
            studentidbox.Location = new Point(291, 132);
            studentidbox.Name = "studentidbox";
            studentidbox.Size = new Size(198, 23);
            studentidbox.TabIndex = 42;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(135, 30);
            label6.Name = "label6";
            label6.Size = new Size(466, 47);
            label6.TabIndex = 41;
            label6.Text = "Enter the following Credentials";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(135, 182);
            label2.Name = "label2";
            label2.Size = new Size(94, 28);
            label2.TabIndex = 38;
            label2.Text = "Course ID";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(135, 127);
            label1.Name = "label1";
            label1.Size = new Size(112, 28);
            label1.TabIndex = 37;
            label1.Text = "Student ID";
            // 
            // AssigningCourse
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(coursenamebox);
            Controls.Add(studentidbox);
            Controls.Add(label6);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AssigningCourse";
            Text = "Assigning Course";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private TextBox coursenamebox;
        private TextBox studentidbox;
        private Label label6;
        private Label label2;
        private Label label1;
    }
}