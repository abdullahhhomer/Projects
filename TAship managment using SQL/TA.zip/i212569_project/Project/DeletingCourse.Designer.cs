﻿namespace Project
{
    partial class DeletingCourse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeletingCourse));
            button2 = new Button();
            button1 = new Button();
            sectionbox = new TextBox();
            courseidbox = new TextBox();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(354, 231);
            button2.Name = "button2";
            button2.Size = new Size(114, 23);
            button2.TabIndex = 23;
            button2.Text = "Back To List";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(373, 184);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 22;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // sectionbox
            // 
            sectionbox.Location = new Point(310, 138);
            sectionbox.Name = "sectionbox";
            sectionbox.Size = new Size(193, 23);
            sectionbox.TabIndex = 21;
            // 
            // courseidbox
            // 
            courseidbox.Location = new Point(310, 84);
            courseidbox.Name = "courseidbox";
            courseidbox.Size = new Size(193, 23);
            courseidbox.TabIndex = 20;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(181, 133);
            label2.Name = "label2";
            label2.Size = new Size(80, 28);
            label2.TabIndex = 19;
            label2.Text = "Section";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(181, 77);
            label1.Name = "label1";
            label1.Size = new Size(103, 28);
            label1.TabIndex = 18;
            label1.Text = "Course ID";
            // 
            // DeletingCourse
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(sectionbox);
            Controls.Add(courseidbox);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "DeletingCourse";
            Text = "Deleting Course";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private TextBox sectionbox;
        private TextBox courseidbox;
        private Label label2;
        private Label label1;
    }
}