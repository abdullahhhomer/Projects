﻿namespace Project
{
    partial class adminMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminMenu));
            button1 = new Button();
            label1 = new Label();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(309, 103);
            button1.Name = "button1";
            button1.Size = new Size(116, 23);
            button1.TabIndex = 0;
            button1.Text = "Faculty";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Display", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(247, 22);
            label1.Name = "label1";
            label1.Size = new Size(224, 35);
            label1.TabIndex = 1;
            label1.Text = "Choose from the List";
            // 
            // button2
            // 
            button2.Location = new Point(309, 132);
            button2.Name = "button2";
            button2.Size = new Size(116, 23);
            button2.TabIndex = 2;
            button2.Text = "TA";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(309, 161);
            button3.Name = "button3";
            button3.Size = new Size(116, 23);
            button3.TabIndex = 3;
            button3.Text = "LD";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(309, 248);
            button4.Name = "button4";
            button4.Size = new Size(116, 23);
            button4.TabIndex = 4;
            button4.Text = "Payment";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(535, 287);
            button5.Name = "button5";
            button5.Size = new Size(158, 23);
            button5.TabIndex = 5;
            button5.Text = "Back to Selection Page";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(139, 287);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 6;
            button6.Text = "Exit";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(309, 74);
            button7.Name = "button7";
            button7.Size = new Size(116, 23);
            button7.TabIndex = 7;
            button7.Text = "Add Person";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(309, 190);
            button8.Name = "button8";
            button8.Size = new Size(116, 23);
            button8.TabIndex = 8;
            button8.Text = "Course";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(309, 219);
            button9.Name = "button9";
            button9.Size = new Size(116, 23);
            button9.TabIndex = 9;
            button9.Text = "Course Allocation";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click_1;
            // 
            // adminMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label1);
            Controls.Add(button1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "adminMenu";
            Text = "Admin Menu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
    }
}