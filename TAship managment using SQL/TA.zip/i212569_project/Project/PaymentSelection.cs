﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class PaymentSelection : Form
    {
        public PaymentSelection()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                string selectedOption = comboBox1.SelectedItem.ToString();

                if (selectedOption == "LD")
                {
                    // Code for Admin option
                    LDPayment student = new LDPayment();
                    this.Visible = false;
                    student.Visible = true;
                }
                else if (selectedOption == "TA")
                {
                    // Code for Faculty option
                    TAPayment student = new TAPayment();
                    this.Visible = false;
                    student.Visible = true;
                }
            }
            else
            {
                MessageBox.Show("\nInvalid Selection");
                PaymentSelection n = new PaymentSelection();
                this.Visible = false;
                n.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminMenu adminMenu = new adminMenu();
            this.Visible = false;
            adminMenu.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ViewPayment payment = new ViewPayment();
            this.Visible=false;
            payment.Visible = true;
        }
    }
}
