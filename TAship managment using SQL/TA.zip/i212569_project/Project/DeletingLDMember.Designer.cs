﻿namespace Project
{
    partial class DeletingLDMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeletingLDMember));
            button2 = new Button();
            button1 = new Button();
            passwordbox = new TextBox();
            facultybox = new TextBox();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(349, 231);
            button2.Name = "button2";
            button2.Size = new Size(114, 23);
            button2.TabIndex = 17;
            button2.Text = "Back To List";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(368, 184);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 16;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // passwordbox
            // 
            passwordbox.Location = new Point(305, 138);
            passwordbox.Name = "passwordbox";
            passwordbox.Size = new Size(193, 23);
            passwordbox.TabIndex = 15;
            // 
            // facultybox
            // 
            facultybox.Location = new Point(305, 84);
            facultybox.Name = "facultybox";
            facultybox.Size = new Size(193, 23);
            facultybox.TabIndex = 14;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(176, 133);
            label2.Name = "label2";
            label2.Size = new Size(103, 28);
            label2.TabIndex = 13;
            label2.Text = "Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(176, 77);
            label1.Name = "label1";
            label1.Size = new Size(112, 28);
            label1.TabIndex = 12;
            label1.Text = "Student ID";
            // 
            // DelectingLDMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(passwordbox);
            Controls.Add(facultybox);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "DelectingLDMember";
            Text = "Delecting LD Member";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private TextBox passwordbox;
        private TextBox facultybox;
        private Label label2;
        private Label label1;
    }
}