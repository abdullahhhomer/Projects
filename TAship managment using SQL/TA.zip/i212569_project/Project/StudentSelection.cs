﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class StudentSelection : Form
    {
        public StudentSelection()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedItem != null)
            {
                string selectedOption = comboBox1.SelectedItem.ToString();

                if (selectedOption == "LD")
                {
                    // Code for Admin option
                    AdminLogin student = new AdminLogin();
                    this.Visible = false;
                    student.Visible = true;
                }
                else if (selectedOption == "TA")
                {
                    // Code for Faculty option
                    FacultyLogin student = new FacultyLogin();
                    this.Visible = false;
                    student.Visible = true;
                }
            }
            else
            {
                MessageBox.Show("\nInvalid Selection");
                Selection n = new Selection();
                this.Visible = false;
                n.Visible = true;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
