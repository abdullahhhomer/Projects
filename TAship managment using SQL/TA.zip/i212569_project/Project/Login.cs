using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Xml.Serialization;
namespace Project
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Login_Click(object sender, EventArgs e)
        {
            var username = useridbox.Text;
            var password = passwordbox.Text;
            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
            using (SqlConnection sql = new SqlConnection(connectionString))
            {
                sql.Open();
                string query = $"select * from Tasks where Username = '{username}' and Password = '{password}'";
                using (SqlCommand cmd = new SqlCommand(query, sql))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            adminMenu n = new adminMenu();
                            this.Visible = false;
                            n.Visible = true;
                        }
                        else
                        {
                            // No matching user found
                            MessageBox.Show("Invalid username or password");
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("\nDo you want to exit", "exit",
                             MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                this.Show();
            }
        }

        //private void button2_Click(object sender, EventArgs e)
        ////{
        ////    registration reg = new registration();
        ////    reg.Visible = true;
        ////    this.Visible = false;
        //}
    }
}