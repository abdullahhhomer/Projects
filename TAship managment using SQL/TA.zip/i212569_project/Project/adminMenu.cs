﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class adminMenu : Form
    {
        public adminMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            adminFacultymenu c = new adminFacultymenu();
            this.Visible = false;
            c.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("\nDo you want to exit", "Exit",
                             MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                this.Show();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Selection s = new Selection();
            this.Visible = false;
            s.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminTAMenu adminTAMenu = new AdminTAMenu();
            this.Visible = false;
            adminTAMenu.Visible = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            addingperson p = new addingperson();
            this.Visible = false;
            p.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdminLDMenu adminLDMenu = new AdminLDMenu();
            this.Visible = false;
            adminLDMenu.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PaymentSelection payment = new PaymentSelection();
            this.Visible = false;
            payment.Visible = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            AdminCourseMenu adminCourseMenu = new AdminCourseMenu();
            this.Visible = false;
            adminCourseMenu.Visible = true;
        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            AdminCourseAllocation n=new AdminCourseAllocation();   
            this.Visible = false;
            n.Visible = true;
        }
    }
}
