﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class DeletingCourse : Form
    {
        public DeletingCourse()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var fid = courseidbox.Text;
            var pas = sectionbox.Text;

            // Display confirmation message
            DialogResult result = MessageBox.Show("Are you sure you want to delete this student member?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    // Use parameters to avoid SQL injection
                    string query = "DELETE FROM Course1 WHERE CourseID = @CourseID AND Section = @Section";
                    SqlCommand command = new SqlCommand(query, sqlConnection);
                    command.Parameters.AddWithValue("@CourseID", fid);
                    command.Parameters.AddWithValue("@Section", pas);

                    int res = command.ExecuteNonQuery();

                    if (res != 0)
                    {
                        MessageBox.Show("Course Deleted Successfully");
                        ViewingCourse form2 = new ViewingCourse();
                        form2.Visible = true;
                        this.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Course Deletion failed \nCheck for the ID or the " +
                                        "Course doesn't exist in the database ");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminCourseMenu adminCourseMenu = new AdminCourseMenu();
            this.Visible = false;
            adminCourseMenu.Visible = true;
        }
    }
}
