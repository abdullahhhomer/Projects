﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class FacultyMenu : Form
    {
        string str1, str2;

        private void FacultyMenu_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            viewTA_as_faculty ve = new viewTA_as_faculty(str1, str2);
            this.Visible = false;
            ve.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            viewLD_s_as_faculty ve = new viewLD_s_as_faculty(str1, str2);
            this.Visible = false;
            ve.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        public FacultyMenu(string s1,string s2)
        {
            str1 = s1;
            str2 = s2;
            InitializeComponent();
        }
    }
}
