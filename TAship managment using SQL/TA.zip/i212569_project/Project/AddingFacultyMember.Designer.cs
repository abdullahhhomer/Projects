﻿namespace Project
{
    partial class AddingFacultyMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddingFacultyMember));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            idbox = new TextBox();
            emailbox = new TextBox();
            passwordbox = new TextBox();
            namebox = new TextBox();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(162, 90);
            label1.Name = "label1";
            label1.Size = new Size(103, 28);
            label1.TabIndex = 0;
            label1.Text = "Person ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(158, 130);
            label2.Name = "label2";
            label2.Size = new Size(127, 28);
            label2.TabIndex = 1;
            label2.Text = "Faculty Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(176, 165);
            label3.Name = "label3";
            label3.Size = new Size(93, 28);
            label3.TabIndex = 2;
            label3.Text = "Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(176, 198);
            label4.Name = "label4";
            label4.Size = new Size(62, 28);
            label4.TabIndex = 3;
            label4.Text = "Email";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(158, 19);
            label6.Name = "label6";
            label6.Size = new Size(466, 47);
            label6.TabIndex = 5;
            label6.Text = "Enter the following Credentials";
            // 
            // idbox
            // 
            idbox.Location = new Point(309, 90);
            idbox.Name = "idbox";
            idbox.Size = new Size(198, 23);
            idbox.TabIndex = 6;
            // 
            // emailbox
            // 
            emailbox.Location = new Point(309, 198);
            emailbox.Name = "emailbox";
            emailbox.Size = new Size(198, 23);
            emailbox.TabIndex = 7;
            // 
            // passwordbox
            // 
            passwordbox.Location = new Point(309, 165);
            passwordbox.Name = "passwordbox";
            passwordbox.Size = new Size(198, 23);
            passwordbox.TabIndex = 11;
            // 
            // namebox
            // 
            namebox.Location = new Point(309, 130);
            namebox.Name = "namebox";
            namebox.Size = new Size(198, 23);
            namebox.TabIndex = 12;
            // 
            // button1
            // 
            button1.Location = new Point(366, 247);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 13;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(333, 295);
            button2.Name = "button2";
            button2.Size = new Size(147, 23);
            button2.TabIndex = 14;
            button2.Text = "Back to List";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // AddingFacultyMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(namebox);
            Controls.Add(passwordbox);
            Controls.Add(emailbox);
            Controls.Add(idbox);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddingFacultyMember";
            Text = "Adding Faculty Member";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private TextBox idbox;
        private TextBox emailbox;
        private TextBox passwordbox;
        private TextBox namebox;
        private Button button1;
        private Button button2;
    }
}