﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class update_tasks_for_user_logged_in : Form
    {
        private string str1, str2;
        public update_tasks_for_user_logged_in(string s1,string s2)
        {
            str1 = s1;
            str2 = s2;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string taskID = textBox1.Text;

            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                              "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string updateQuery = "UPDATE Task1 SET Status = 1 WHERE taskID = @taskID";

                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@taskID", taskID);

                    int rowsAffected = updateCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Task status updated successfully.");

                    }
                    else
                    {
                        MessageBox.Show("Task not found or status could not be updated.");
                    }
                }
            }
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Student_menu men = new Student_menu(str1, str2);
            this.Visible = false;
            men.Visible = true;
        }

        private void update_tasks_for_user_logged_in_Load(object sender, EventArgs e)
        {

        }
    }
}
