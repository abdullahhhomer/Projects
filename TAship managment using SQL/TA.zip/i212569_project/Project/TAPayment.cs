﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class TAPayment : Form
    {
        public TAPayment()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Validate that all fields are filled
            if (string.IsNullOrWhiteSpace(id1box.Text) || string.IsNullOrWhiteSpace(idbox.Text) ||
                string.IsNullOrWhiteSpace(amtbox.Text))
            {
                MessageBox.Show("Please fill in all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate that the amount is a valid number
            if (!decimal.TryParse(amtbox.Text, out decimal amount))
            {
                MessageBox.Show("Please enter a valid amount.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Assuming you have a Payment1 table with columns: paymentID, studentid, adminid, payment, paymentDate
            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";

            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();

                // Check if the student ID exists in the Student1 table
                string checkStudentQuery = "SELECT COUNT(*) FROM Student1 WHERE StudentID = @studentID";
                using (SqlCommand checkStudentCommand = new SqlCommand(checkStudentQuery, sqlConnection))
                {
                    checkStudentCommand.Parameters.AddWithValue("@studentID", id1box.Text);
                    int studentCount = Convert.ToInt32(checkStudentCommand.ExecuteScalar());

                    if (studentCount == 0)
                    {
                        MessageBox.Show("Student ID does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                // Check if the admin ID exists in the Admin table
                string checkAdminQuery = "SELECT COUNT(*) FROM Admin1 WHERE AdminID = @adminID";
                using (SqlCommand checkAdminCommand = new SqlCommand(checkAdminQuery, sqlConnection))
                {
                    checkAdminCommand.Parameters.AddWithValue("@adminID", idbox.Text);
                    int adminCount = Convert.ToInt32(checkAdminCommand.ExecuteScalar());

                    if (adminCount == 0)
                    {
                        MessageBox.Show("Admin ID does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                // Proceed with adding the payment
                string insertQuery = "INSERT INTO Payment1 (paymentID, payment, paymentDate, adminid,studentid) " +
                         "VALUES (@paymentID, @amount, @paymentDate, @adminID, @studentID)";

                using (SqlCommand insertCommand = new SqlCommand(insertQuery, sqlConnection))
                {
                    insertCommand.Parameters.AddWithValue("@paymentID", paymentidbox.Text);
                    insertCommand.Parameters.AddWithValue("@studentID", id1box.Text);
                    insertCommand.Parameters.AddWithValue("@adminID", idbox.Text);
                    insertCommand.Parameters.AddWithValue("@amount", amount);
                    insertCommand.Parameters.AddWithValue("@paymentDate", DateTime.Now);

                    int res = insertCommand.ExecuteNonQuery();

                    if (res != 0)
                    {
                        MessageBox.Show("Payment added successfully. Payment ID: " + paymentidbox.Text);
                        // Additional logic if needed, such as updating the student's balance
                    }
                    else
                    {
                        MessageBox.Show("Payment addition failed.");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PaymentSelection payment = new PaymentSelection();
            this.Visible = false;
            payment.Visible = true;
        }
    }
}
