﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class AssigningCourse : Form
    {
        public AssigningCourse()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Validate that all fields are filled
            if (string.IsNullOrWhiteSpace(studentidbox.Text) || string.IsNullOrWhiteSpace(coursenamebox.Text))
            {
                MessageBox.Show("Please fill in all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var courseId = coursenamebox.Text;
            var studentId = studentidbox.Text;

            // Additional input validation (you can customize this based on your requirements)
            if (courseId.Length > 10 || studentId.Length > 10)
            {
                MessageBox.Show("Course ID and Student ID should not exceed 10 characters.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    // Check if the course exists in Course1
                    string checkCourseQuery = "SELECT COUNT(*) FROM Course1 WHERE CourseID = @courseId";
                    using (SqlCommand checkCourseCommand = new SqlCommand(checkCourseQuery, sqlConnection))
                    {
                        checkCourseCommand.Parameters.AddWithValue("@courseId", courseId);

                        int courseCount = Convert.ToInt32(checkCourseCommand.ExecuteScalar());

                        if (courseCount == 0)
                        {
                            MessageBox.Show("Course does not exist in Course1 table. Please enter a valid course.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Check if the student exists in Student1
                    string checkStudentQuery = "SELECT COUNT(*) FROM Student1 WHERE StudentID = @studentId";
                    using (SqlCommand checkStudentCommand = new SqlCommand(checkStudentQuery, sqlConnection))
                    {
                        checkStudentCommand.Parameters.AddWithValue("@studentId", studentId);

                        int studentCount = Convert.ToInt32(checkStudentCommand.ExecuteScalar());

                        if (studentCount == 0)
                        {
                            MessageBox.Show("Student does not exist in Student1 table. Please enter a valid student.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Check if the student ID and course ID combination already exists in the CourseAllocated table
                    string checkQuery = "SELECT COUNT(*) FROM CourseAllocated WHERE courseId1 = @courseId AND studentId1 = @studentId";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, sqlConnection))
                    {
                        checkCommand.Parameters.AddWithValue("@courseId", courseId);
                        checkCommand.Parameters.AddWithValue("@studentId", studentId);

                        int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                        if (count > 0)
                        {
                            // Combination of course ID and student ID already exists, show a message
                            MessageBox.Show("Course and student combination already exists in the CourseAllocated table. Please use a different combination.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            // Combination of course ID and student ID doesn't exist, proceed with adding the record
                            string insertQuery = "INSERT INTO CourseAllocated (courseId1, studentId1) VALUES (@courseId, @studentId)";
                            using (SqlCommand insertCommand = new SqlCommand(insertQuery, sqlConnection))
                            {
                                insertCommand.Parameters.AddWithValue("@courseId", courseId);
                                insertCommand.Parameters.AddWithValue("@studentId", studentId);

                                int res = insertCommand.ExecuteNonQuery();

                                if (res != 0)
                                {
                                    MessageBox.Show("Course Allocated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    // Clear input fields
                                    coursenamebox.Text = "";
                                    studentidbox.Text = "";
                                }
                                else
                                {
                                    MessageBox.Show("Course Allocation failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                // Handle SQL exceptions
                MessageBox.Show($"SQL Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                // Handle other exceptions
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminCourseAllocation adminCourseMenu = new AdminCourseAllocation();
            this.Visible = false;
            adminCourseMenu.Visible = true;
        }
    }
}