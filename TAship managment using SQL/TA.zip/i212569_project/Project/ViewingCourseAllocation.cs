﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ViewingCourseAllocation : Form
    {
        public ViewingCourseAllocation()
        {
            InitializeComponent();
            populateData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AssigningCourse b = new AssigningCourse();
            this.Visible = false;
            b.Visible = true;
        }
        public void populateData()
        {
            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";

            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();

                string query = "SELECT CA.courseId1, CA.studentId1, C.Section " +
                               "FROM CourseAllocated CA " +
                               "JOIN Course1 C ON CA.courseId1 = C.CourseID";

                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        dataGridView1.Columns.Clear(); // Clear existing columns
                        dataGridView1.Rows.Clear();    // Clear existing rows

                        dataGridView1.Columns.Add("CourseID", "Course ID");
                        dataGridView1.Columns.Add("StudentID", "Student ID");
                        dataGridView1.Columns.Add("Section", "Course Section");

                        while (reader.Read())
                        {
                            string courseId = reader["courseId1"].ToString();
                            string studentId = reader["studentId1"].ToString();
                            string courseSection = reader["Section"].ToString();

                            dataGridView1.Rows.Add(courseId, studentId, courseSection);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No Data");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminCourseAllocation adminCourseAllocation = new AdminCourseAllocation();
            this.Visible = false;
            adminCourseAllocation.Visible = true;
        }
    }
}