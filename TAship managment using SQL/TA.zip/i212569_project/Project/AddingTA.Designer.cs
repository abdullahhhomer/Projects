﻿namespace Project
{
    partial class AddingTA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddingTA));
            button2 = new Button();
            button1 = new Button();
            namebox = new TextBox();
            passwordbox = new TextBox();
            emailbox = new TextBox();
            idbox = new TextBox();
            label6 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(315, 302);
            button2.Name = "button2";
            button2.Size = new Size(147, 23);
            button2.TabIndex = 25;
            button2.Text = "Back to List";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(348, 254);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 24;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // namebox
            // 
            namebox.Location = new Point(291, 137);
            namebox.Name = "namebox";
            namebox.Size = new Size(198, 23);
            namebox.TabIndex = 23;
            // 
            // passwordbox
            // 
            passwordbox.Location = new Point(291, 172);
            passwordbox.Name = "passwordbox";
            passwordbox.Size = new Size(198, 23);
            passwordbox.TabIndex = 22;
            // 
            // emailbox
            // 
            emailbox.Location = new Point(291, 205);
            emailbox.Name = "emailbox";
            emailbox.Size = new Size(198, 23);
            emailbox.TabIndex = 21;
            // 
            // idbox
            // 
            idbox.Location = new Point(291, 97);
            idbox.Name = "idbox";
            idbox.Size = new Size(198, 23);
            idbox.TabIndex = 20;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(140, 26);
            label6.Name = "label6";
            label6.Size = new Size(466, 47);
            label6.TabIndex = 19;
            label6.Text = "Enter the following Credentials";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(158, 205);
            label4.Name = "label4";
            label4.Size = new Size(62, 28);
            label4.TabIndex = 18;
            label4.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(158, 172);
            label3.Name = "label3";
            label3.Size = new Size(93, 28);
            label3.TabIndex = 17;
            label3.Text = "Password";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(140, 137);
            label2.Name = "label2";
            label2.Size = new Size(131, 28);
            label2.TabIndex = 16;
            label2.Text = "Student Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(144, 97);
            label1.Name = "label1";
            label1.Size = new Size(103, 28);
            label1.TabIndex = 15;
            label1.Text = "Person ID";
            // 
            // AddingTA
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(namebox);
            Controls.Add(passwordbox);
            Controls.Add(emailbox);
            Controls.Add(idbox);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "AddingTA";
            Text = "Adding TA";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private TextBox namebox;
        private TextBox passwordbox;
        private TextBox emailbox;
        private TextBox idbox;
        private Label label6;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}