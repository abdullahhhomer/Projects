﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ViewTasks_for_user_loggedin : Form
    {
        private string s1, s2;
        public ViewTasks_for_user_loggedin(string str1,string str2)
        {
            s1 = str1;
            s2 = str2;
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
                string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                          "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";

                using (SqlConnection sql = new SqlConnection(connectionString))
                {
                    sql.Open();
                    string query = @"
            SELECT TaskID, TaskName, description, DeadLine, Status, feedbackText, feedbackDate,
                   facultyId, StudentID, courseID
            FROM Task1
            WHERE StudentID = (SELECT StudentID FROM Student1 WHERE StudentName = @s1 AND StudentPassword = @s2);";

                    using (SqlCommand cmd = new SqlCommand(query, sql))
                    {
                        cmd.Parameters.AddWithValue("@s1", s1);
                        cmd.Parameters.AddWithValue("@s2", s2);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                // Access task details from reader
                                string taskId = reader["TaskID"].ToString();
                                string taskName = reader["TaskName"].ToString();
                                string description = reader["description"].ToString();
                                DateTime deadLine = Convert.ToDateTime(reader["DeadLine"]);
                                bool status = Convert.ToBoolean(reader["Status"]);
                                string feedbackText = reader["feedbackText"].ToString();
                                DateTime feedbackDate = Convert.ToDateTime(reader["feedbackDate"]);
                                string facultyId = reader["facultyId"].ToString();
                                string studentId = reader["StudentID"].ToString();
                                string courseId = reader["courseID"].ToString();

                                // Use task details as needed (e.g., display in DataGridView, ListBox, etc.)
                                // For example, you can display them in a DataGridView
                                dataGridView1.Rows.Add(taskId, taskName, description, deadLine, status, feedbackText, feedbackDate, facultyId, studentId, courseId);
                            }
                        }
                    }
                }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student_menu va = new Student_menu(s1, s2);
            this.Visible = false;
            va.Visible = true;
        }
    }
}
