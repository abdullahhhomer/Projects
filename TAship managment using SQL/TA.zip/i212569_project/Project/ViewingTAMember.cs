﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ViewingTAMember : Form
    {
        bool value = false;//false indicates it's admin
        string st1, st2;
        public ViewingTAMember(bool v = false, string str1 = " ", string str2 = " ")
        {
            value = v;
            st1 = str1;
            st2 = str2;
            InitializeComponent();
            populateData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addingperson p = new addingperson();
            this.Visible = false;
            p.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (value)
            {
                Student_menu men = new Student_menu(st1, st2);
                this.Visible = false;
                men.Visible = true;
            }
            else
            {
                AdminTAMenu menu = new AdminTAMenu();
                this.Visible = false;
                menu.Visible = true;
            }
        }

            private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void populateData()
        {
            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
            SqlConnection sql = new SqlConnection(connectionString);
            sql.Open();
            string query = "select * from Student1";
            SqlCommand cmd = new SqlCommand(query, sql);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                dataGridView1.Columns.Add("StudentID", "Student ID");
                dataGridView1.Columns.Add("StudentName", "Student Name");
                dataGridView1.Columns.Add("StudentPassword", "Password");
                dataGridView1.Columns.Add("StudentEmail", "Email");

                while (reader.Read())
                {
                    string username = reader["StudentID"].ToString();
                    string fname = reader["StudentName"].ToString();
                    string password = reader["StudentPassword"].ToString();
                    string due = reader["StudentEmail"].ToString();
                    dataGridView1.Rows.Add(username, fname, password, due);
                }
            }
            else
            {
                MessageBox.Show("No Data");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
