﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class give_feedback_to_student_on_task : Form
    {
        private string s1, s2;
        public give_feedback_to_student_on_task(string str1,string str2)
        {
            s1 = str1;
            s2 = str2;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string taskId = taskID.ToString();
            string feedback = feedbackte.ToString();

            
            if (string.IsNullOrEmpty(taskId) || string.IsNullOrEmpty(feedback))
            {
                MessageBox.Show("Task ID and feedback are required.");
                return;
            }

            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";

            using (SqlConnection sql = new SqlConnection(connectionString))
            {
                sql.Open();

                string query = "UPDATE Task1 SET feedbackText = @feedback WHERE taskID = @taskId";

                using (SqlCommand cmd = new SqlCommand(query, sql))
                {
                    cmd.Parameters.AddWithValue("@feedback", feedback);
                    cmd.Parameters.AddWithValue("@taskId", taskId);

                    try
                    {
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Feedback updated successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Task ID not found or no rows updated.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error updating feedback: {ex.Message}");
                    }
                }
            }
        }




        private void taskID_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FacultyMenu men = new FacultyMenu(s1, s2);
            this.Visible = false;
            men.Visible = true;
        }
    }
}
