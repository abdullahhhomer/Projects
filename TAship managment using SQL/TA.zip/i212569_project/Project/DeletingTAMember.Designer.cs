﻿namespace Project
{
    partial class DeletingTAMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeletingTAMember));
            button2 = new Button();
            button1 = new Button();
            passwordbox = new TextBox();
            facultybox = new TextBox();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(345, 240);
            button2.Name = "button2";
            button2.Size = new Size(114, 23);
            button2.TabIndex = 11;
            button2.Text = "Back To List";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(364, 193);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 10;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // passwordbox
            // 
            passwordbox.Location = new Point(301, 147);
            passwordbox.Name = "passwordbox";
            passwordbox.Size = new Size(193, 23);
            passwordbox.TabIndex = 9;
            // 
            // facultybox
            // 
            facultybox.Location = new Point(301, 93);
            facultybox.Name = "facultybox";
            facultybox.Size = new Size(193, 23);
            facultybox.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(172, 142);
            label2.Name = "label2";
            label2.Size = new Size(103, 28);
            label2.TabIndex = 7;
            label2.Text = "Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(172, 86);
            label1.Name = "label1";
            label1.Size = new Size(112, 28);
            label1.TabIndex = 6;
            label1.Text = "Student ID";
            // 
            // DeletingTAMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(passwordbox);
            Controls.Add(facultybox);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "DeletingTAMember";
            Text = "Deleting TA Member";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private TextBox passwordbox;
        private TextBox facultybox;
        private Label label2;
        private Label label1;
    }
}