﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class viewLD_s_as_faculty : Form
    {
        string str1, str2;
        public viewLD_s_as_faculty(string s1,string s2)
        {
            str1 = s1;
            str2 = s2;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FacultyMenu men = new FacultyMenu(str1, str2);
            this.Visible = false;
            men.Visible = true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                              "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";

            using (SqlConnection sql = new SqlConnection(connectionString))
            {
                sql.Open();

                string query = @"
            SELECT
                L.LID AS LD_ID,
                P.StudentName AS LD_Name,
                P.StudentEmail AS LD_Email,
                L.NumberOfStudents AS Students_Count,
                L.from1 AS LD_Start_Date,
                L.to1 AS LD_End_Date
            FROM
                LD L
            JOIN
                Student1 P ON L.LID = P.StudentID
            JOIN
                Person U ON P.StudentID = U.PersonID;
        ";

                using (SqlCommand cmd = new SqlCommand(query, sql))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
        }
    }
}
