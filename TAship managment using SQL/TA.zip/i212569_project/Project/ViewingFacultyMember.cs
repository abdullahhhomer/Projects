﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ViewingFacultyMember : Form
    {
        public ViewingFacultyMember()
        {
            InitializeComponent();
            populateData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void populateData()
        {
            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                     "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
            SqlConnection sql = new SqlConnection(connectionString);
            sql.Open();
            string query = "select * from Faculty1";
            SqlCommand cmd = new SqlCommand(query, sql);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                dataGridView1.Columns.Add("FacultyID", "Faculty ID");
                dataGridView1.Columns.Add("FacultyName", "Faculty Name");
                dataGridView1.Columns.Add("FacultyPassword", "Password");
                dataGridView1.Columns.Add("FacultyEmail", "Email");

                while (reader.Read())
                {
                    string username = reader["FacultyID"].ToString();
                    string fname = reader["FacultyName"].ToString();
                    string password = reader["FacultyPassword"].ToString();
                    string due = reader["FacultyEmail"].ToString();
                    dataGridView1.Rows.Add(username, fname, password, due);
                }
            }
            else
            {
                MessageBox.Show("No Data");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addingperson p = new addingperson();
            this.Visible = false;
            p.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminFacultymenu menu = new adminFacultymenu();
            this.Visible = false;
            menu.Visible = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
