﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class AdminCourseMenu : Form
    {
        public AdminCourseMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddingCourse addingCourse = new AddingCourse();
            this.Visible = false;
            addingCourse.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewingCourse viewingCourse = new ViewingCourse();
            this.Visible = false;
            viewingCourse.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            adminMenu adminMenu = new adminMenu();
            this.Visible = false;
            adminMenu.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeletingCourse deletingCourse = new DeletingCourse();
            this.Visible = false;
            deletingCourse.Visible = true;
        }
    }
}
