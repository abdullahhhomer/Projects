﻿namespace Project
{
    partial class TAPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TAPayment));
            label4 = new Label();
            paymentidbox = new TextBox();
            button2 = new Button();
            id1box = new TextBox();
            label3 = new Label();
            button1 = new Button();
            amtbox = new TextBox();
            label2 = new Label();
            idbox = new TextBox();
            label6 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(119, 97);
            label4.Name = "label4";
            label4.Size = new Size(121, 28);
            label4.TabIndex = 42;
            label4.Text = "Payment ID";
            // 
            // paymentidbox
            // 
            paymentidbox.Location = new Point(270, 102);
            paymentidbox.Name = "paymentidbox";
            paymentidbox.Size = new Size(198, 23);
            paymentidbox.TabIndex = 41;
            // 
            // button2
            // 
            button2.Location = new Point(307, 278);
            button2.Name = "button2";
            button2.Size = new Size(124, 23);
            button2.TabIndex = 40;
            button2.Text = "Back To List";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // id1box
            // 
            id1box.Location = new Point(270, 175);
            id1box.Name = "id1box";
            id1box.Size = new Size(198, 23);
            id1box.TabIndex = 39;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(119, 175);
            label3.Name = "label3";
            label3.Size = new Size(64, 28);
            label3.TabIndex = 38;
            label3.Text = "TA ID";
            // 
            // button1
            // 
            button1.Location = new Point(333, 239);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 37;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // amtbox
            // 
            amtbox.Location = new Point(270, 210);
            amtbox.Name = "amtbox";
            amtbox.Size = new Size(198, 23);
            amtbox.TabIndex = 36;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(119, 203);
            label2.Name = "label2";
            label2.Size = new Size(86, 28);
            label2.TabIndex = 35;
            label2.Text = "Amount";
            // 
            // idbox
            // 
            idbox.Location = new Point(270, 142);
            idbox.Name = "idbox";
            idbox.Size = new Size(198, 23);
            idbox.TabIndex = 34;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Heading", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(119, 36);
            label6.Name = "label6";
            label6.Size = new Size(466, 47);
            label6.TabIndex = 33;
            label6.Text = "Enter the following Credentials";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Text", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(119, 137);
            label1.Name = "label1";
            label1.Size = new Size(101, 28);
            label1.TabIndex = 32;
            label1.Text = "Admin ID";
            // 
            // TAPayment
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(paymentidbox);
            Controls.Add(button2);
            Controls.Add(id1box);
            Controls.Add(label3);
            Controls.Add(button1);
            Controls.Add(amtbox);
            Controls.Add(label2);
            Controls.Add(idbox);
            Controls.Add(label6);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "TAPayment";
            Text = "TA Payment";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label4;
        private TextBox paymentidbox;
        private Button button2;
        private TextBox id1box;
        private Label label3;
        private Button button1;
        private TextBox amtbox;
        private Label label2;
        private TextBox idbox;
        private Label label6;
        private Label label1;
    }
}