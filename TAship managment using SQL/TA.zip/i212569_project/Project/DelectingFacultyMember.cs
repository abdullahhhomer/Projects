﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class DelectingFacultyMember : Form
    {
        public DelectingFacultyMember()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var fid = facultybox.Text;
            var pas = passwordbox.Text;

            // Display confirmation message
            DialogResult result = MessageBox.Show("Are you sure you want to delete this faculty member?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    // Use parameters to avoid SQL injection
                    string query = "DELETE FROM Faculty1 WHERE FacultyID = @FacultyID AND FacultyPassword = @FacultyPassword";
                    SqlCommand command = new SqlCommand(query, sqlConnection);
                    command.Parameters.AddWithValue("@FacultyID", fid);
                    command.Parameters.AddWithValue("@FacultyPassword", pas);

                    int res = command.ExecuteNonQuery();

                    if (res != 0)
                    {
                        MessageBox.Show("Faculty Deleted Successfully");
                        ViewingFacultyMember form2 = new ViewingFacultyMember();
                        form2.Visible = true;
                        this.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Faculty Deletion failed \nCheck for the ID or the " +
                                        "Person doesn't exits in the database ");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminFacultymenu n = new adminFacultymenu();
            this.Visible = false;
            n.Visible = true;
        }
    }
}
