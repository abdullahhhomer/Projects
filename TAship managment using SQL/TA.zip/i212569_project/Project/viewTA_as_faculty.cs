﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class viewTA_as_faculty : Form
    {
        private string str1, str2;
        public viewTA_as_faculty(string s1,string s2)
        {
            str1 = s1;
            str2 = s2;
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";

            using (SqlConnection sql = new SqlConnection(connectionString))
            {
                sql.Open();

                // SQL query to retrieve the list of all TAs with their details
                string query = @"
            SELECT
                T.TID AS TA_ID,
                P.StudentName AS TA_Name,
                P.StudentEmail AS TA_Email,
                T.NumberOfStudents AS Students_Count,
                T.from1 AS TA_Start_Date,
                T.to1 AS TA_End_Date
            FROM
                TA T
            JOIN
                Student1 P ON T.TID = P.StudentID
            JOIN
                Person U ON P.StudentID = U.PersonID;
        ";

                using (SqlCommand cmd = new SqlCommand(query, sql))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Assuming you have a DataGridView named dataGridView1
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            FacultyMenu men = new FacultyMenu(str1, str2);
            this.Visible = false;
            men.Visible = true;
        }

    }
}
