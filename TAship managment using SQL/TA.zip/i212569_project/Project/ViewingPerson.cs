﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ViewingPerson : Form
    {
        public ViewingPerson()
        {
            InitializeComponent();
            populateData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addingperson p = new addingperson();
            this.Visible = false;
            p.Visible = true;
        }
        public void populateData()
        {
            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
            SqlConnection sql = new SqlConnection(connectionString);
            sql.Open();
            string query = "select * from Person";
            SqlCommand cmd = new SqlCommand(query, sql);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                dataGridView1.Columns.Add("PersonID", "Person ID");
                dataGridView1.Columns.Add("role", "Person Role");

                while (reader.Read())
                {
                    string username = reader["PersonID"].ToString();
                    string fname = reader["role"].ToString();
                    dataGridView1.Rows.Add(username, fname);
                }
            }
            else
            {
                MessageBox.Show("No Data");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminMenu menu = new adminMenu();
            this.Visible = false;
            menu.Visible = true;
        }
    }
}
