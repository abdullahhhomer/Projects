﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class DeallocatingCourse : Form
    {
        public DeallocatingCourse()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var courseId = coursenamebox.Text;
            var studentId = studentidbox.Text;

            // Validate that all fields are filled
            if (string.IsNullOrWhiteSpace(courseId) || string.IsNullOrWhiteSpace(studentId))
            {
                MessageBox.Show("Please fill in all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Display confirmation message
            DialogResult result = MessageBox.Show("Are you sure you want to delete this course allocation?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    // Use parameters to avoid SQL injection
                    string query = "DELETE FROM CourseAllocated WHERE courseId1 = @CourseID AND studentId1 = @StudentID";
                    SqlCommand command = new SqlCommand(query, sqlConnection);
                    command.Parameters.AddWithValue("@CourseID", courseId);
                    command.Parameters.AddWithValue("@StudentID", studentId);

                    int res = command.ExecuteNonQuery();

                    if (res != 0)
                    {
                        MessageBox.Show("Course Allocation Deleted Successfully");
                    }
                    else
                    {
                        MessageBox.Show("Course Allocation Deletion failed. Check for the Course ID and Student ID or the record doesn't exist in the database.");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminCourseAllocation adminCourseAllocation = new AdminCourseAllocation();
            this.Visible = false;
            adminCourseAllocation.Visible = true;
        }
    }
}
