﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Project
{
    public partial class addingperson : Form
    {
        public addingperson()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminMenu m = new adminMenu();
            this.Visible = false;
            m.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var pid = personidbox.Text;
            string selectedOption = comboBox1.SelectedItem?.ToString();

            if (selectedOption != null)
            {
                string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    sqlConnection.Open();

                    // Check if the person with the specified ID already exists
                    string checkQuery = "SELECT COUNT(*) FROM Person WHERE PersonID = @pid";

                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, sqlConnection))
                    {
                        checkCommand.Parameters.AddWithValue("@pid", pid);
                        int existingRecords = (int)checkCommand.ExecuteScalar();

                        if (existingRecords > 0)
                        {
                            MessageBox.Show("Person with ID " + pid + " already exists in the database.");
                            return; // Exit the method without inserting a new record
                        }
                    }

                    // If the person doesn't exist, proceed with the insertion
                    string insertQuery = "INSERT INTO Person VALUES (@pid, @role)";

                    using (SqlCommand command = new SqlCommand(insertQuery, sqlConnection))
                    {
                        command.Parameters.AddWithValue("@pid", pid);
                        command.Parameters.AddWithValue("@role", selectedOption);

                        int res = command.ExecuteNonQuery();

                        if (res != 0)
                        {
                            MessageBox.Show("Person Added Successfully");
                            adminMenu form2 = new adminMenu();
                            form2.Visible = true;
                            this.Visible = false;
                        }
                        else
                        {
                            MessageBox.Show("Person Addition failed");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("\nInvalid Role Selection");
            }
        }

        private void addingperson_Load(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ViewingPerson viewingPerson = new ViewingPerson();
            this.Visible = false;
            viewingPerson.Visible = true;
        }
    }
}
