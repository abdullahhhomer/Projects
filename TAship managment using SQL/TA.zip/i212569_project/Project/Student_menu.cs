﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Student_menu : Form 
    {
        private string s1, s2;
        public Student_menu(string st1, string st2)
        {
            s1 = st1;
            s2 = st2;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ViewTasks_for_user_loggedin v = new ViewTasks_for_user_loggedin(s1, s2);
            this.Visible=false; 
            v.Visible=true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewingLDMember va = new ViewingLDMember(true,s1,s2);
            this.Visible = false;
            va.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ViewingTAMember va = new ViewingTAMember();
            this.Visible = false;
            va.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("\nDo you want to exit", "Exit",
                             MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                this.Show();
            }
        }
    }
}
