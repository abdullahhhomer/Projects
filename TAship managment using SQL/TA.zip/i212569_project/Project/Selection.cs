﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Selection : Form
    {
        public Selection()
        {
            InitializeComponent();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                string selectedOption = comboBox1.SelectedItem.ToString();

                if (selectedOption == "Admin")
                {
                    // Code for Admin option
                    AdminLogin student = new AdminLogin();
                    this.Visible = false;
                    student.Visible = true;
                }
                else if (selectedOption == "Faculty")
                {
                    // Code for Faculty option
                    FacultyLogin student = new FacultyLogin();
                    this.Visible = false;
                    student.Visible = true;
                }
                else if (selectedOption == "Student")
                {
                    StudentLogin men = new StudentLogin();
                    this.Visible = false;
                    men.Visible = true;
                    //// Code for Student option
                    //StudentSelection studentSelection = new StudentSelection();
                    //this.Visible = false;
                    //studentSelection.Visible = true;
                }
            }
            else
            {
                MessageBox.Show("\nInvalid Selection");
                Selection n = new Selection();
                this.Visible = false;
                n.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult res;
            res = MessageBox.Show("\nDo you want to exit", "Exit",
                             MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                this.Show();
            }
        }
    }

}

