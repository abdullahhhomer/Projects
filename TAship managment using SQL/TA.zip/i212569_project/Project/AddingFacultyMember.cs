﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Project
{
    public partial class AddingFacultyMember : Form
    {
        public AddingFacultyMember()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            adminFacultymenu a = new adminFacultymenu();
            this.Visible = false;
            a.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(idbox.Text) || string.IsNullOrWhiteSpace(namebox.Text) ||
                string.IsNullOrWhiteSpace(passwordbox.Text) || string.IsNullOrWhiteSpace(emailbox.Text))
            {
                MessageBox.Show("Please fill in all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            var fid = idbox.Text;
            var fname = namebox.Text;
            var password = passwordbox.Text;
            var email = emailbox.Text;

            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";

            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();

                // Check if the person ID exists in the Person table
                string checkQuery = "SELECT COUNT(*) FROM Person WHERE PersonID = @fid";
                using (SqlCommand checkCommand = new SqlCommand(checkQuery, sqlConnection))
                {
                    checkCommand.Parameters.AddWithValue("@fid", fid);
                    int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                    if (count > 0)
                    {
                        // Person ID exists, proceed with adding the faculty member
                        string insertQuery = "INSERT INTO Faculty1 VALUES (@fid, @fname, @password, @email)";
                        using (SqlCommand command = new SqlCommand(insertQuery, sqlConnection))
                        {
                            // Use parameters to prevent SQL injection
                            command.Parameters.AddWithValue("@fid", fid);
                            command.Parameters.AddWithValue("@fname", fname);
                            command.Parameters.AddWithValue("@password", password);
                            command.Parameters.AddWithValue("@email", email);

                            int res = command.ExecuteNonQuery();

                            if (res != 0)
                            {
                                MessageBox.Show("Faculty Added Successfully");
                                // Refresh the form or clear input fields if needed
                                this.Refresh();
                            }
                            else
                            {
                                MessageBox.Show("Faculty Addition failed");
                            }
                        }
                    }
                    else
                    {
                        // Person ID doesn't exist, show a message
                        MessageBox.Show("Person ID does not exist. Please add the person to the Person table first.");
                    }
                }
            }
        }


    }
}
