﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class AddingCourse : Form
    {
        public AddingCourse()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Validate that all fields are filled
            if (string.IsNullOrWhiteSpace(courseidbox.Text) || string.IsNullOrWhiteSpace(coursenamebox.Text) ||
                string.IsNullOrWhiteSpace(sectionbox.Text) || string.IsNullOrWhiteSpace(adminidbox.Text))
            {
                MessageBox.Show("Please fill in all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var fid = courseidbox.Text;
            var fname = coursenamebox.Text;
            var password = sectionbox.Text;
            var email = adminidbox.Text;

            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();

                // Check if the course ID exists in the Course1 table
                string checkQuery = "SELECT COUNT(*) FROM Course1 WHERE CourseID = @fid";
                using (SqlCommand checkCommand = new SqlCommand(checkQuery, sqlConnection))
                {
                    checkCommand.Parameters.AddWithValue("@fid", fid);
                    int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                    if (count > 0)
                    {
                        // Person ID exists, show a message
                        MessageBox.Show("Course ID already exists in the Course1 table. Please use a different ID.");
                    }
                    else
                    {
                        // Person ID doesn't exist, proceed with adding the student
                        string insertQuery = "INSERT INTO Course1 VALUES (@fid, @fname, @password, @email)";
                        using (SqlCommand insertCommand = new SqlCommand(insertQuery, sqlConnection))
                        {
                            insertCommand.Parameters.AddWithValue("@fid", fid);
                            insertCommand.Parameters.AddWithValue("@fname", fname);
                            insertCommand.Parameters.AddWithValue("@password", password);
                            insertCommand.Parameters.AddWithValue("@email", email);

                            int res = insertCommand.ExecuteNonQuery();

                            if (res != 0)
                            {
                                MessageBox.Show("Course Added Successfully");
                                // Refresh the form or clear input fields if needed
                                this.Refresh();
                            }
                            else
                            {
                                MessageBox.Show("Course Addition failed");
                            }
                        }
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminCourseMenu adminCourseMenu = new AdminCourseMenu();   
            this.Visible = false;
            adminCourseMenu.Visible = true;
        }
    }
}
