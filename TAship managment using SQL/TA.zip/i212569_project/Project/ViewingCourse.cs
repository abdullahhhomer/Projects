﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ViewingCourse : Form
    {
        public ViewingCourse()
        {
            InitializeComponent();
            populateData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddingCourse addingCourse = new AddingCourse();
            this.Visible = false;
            addingCourse.Visible = true;
        }
        public void populateData()
        {
            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";
            SqlConnection sql = new SqlConnection(connectionString);
            sql.Open();
            string query = "select * from Course1";
            SqlCommand cmd = new SqlCommand(query, sql);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                dataGridView1.Columns.Add("CourseID", "Course ID");
                dataGridView1.Columns.Add("CourseName", "Course Name");
                dataGridView1.Columns.Add("Section", "Section");
                dataGridView1.Columns.Add("adminid", "Added by");

                while (reader.Read())
                {
                    string username = reader["CourseID"].ToString();
                    string fname = reader["CourseName"].ToString();
                    string password = reader["Section"].ToString();
                    string due = reader["adminid"].ToString();
                    dataGridView1.Rows.Add(username, fname, password, due);
                }
            }
            else
            {
                MessageBox.Show("No Data");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminCourseMenu adminCourseMenu = new AdminCourseMenu();
            this.Visible = false;
            adminCourseMenu.Visible = true;
        }
    }
}
