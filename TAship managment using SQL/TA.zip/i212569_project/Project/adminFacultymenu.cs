﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Project
{
    public partial class adminFacultymenu : Form
    {
        public adminFacultymenu()
        {
            InitializeComponent();
        }

        private void adminFacultymenu_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddingFacultyMember a = new AddingFacultyMember();
            this.Visible = false;
            a.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewingFacultyMember b = new ViewingFacultyMember();
            this.Visible = false;
            b.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DelectingFacultyMember d = new DelectingFacultyMember();
            this.Visible = false;
            d.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            adminMenu adminMenu = new adminMenu();  
            this.Visible=false;
            adminMenu.Visible = true;
        }
    }
}
