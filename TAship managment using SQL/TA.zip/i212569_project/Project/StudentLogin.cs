﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class StudentLogin : Form
    {
        public StudentLogin()
        {
            InitializeComponent();
        }

        private void useridbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = useridbox.Text.Trim().ToLower(); // Assuming you want to use lowercase
            string password = passwordbox.Text;
            string type = typebox.Text;

            Console.WriteLine($"Debug: Username entered: {username}");
            Console.WriteLine($"Debug: Password entered: {password}");
            Console.WriteLine($"Debug: Type entered: {type}");

            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";

            using (SqlConnection sql = new SqlConnection(connectionString))
            {
                sql.Open();

                string roleQuery = "SELECT role FROM dbo.Person WHERE PersonID = @username COLLATE SQL_Latin1_General_CP1_CS_AS";
                using (SqlCommand roleCmd = new SqlCommand(roleQuery, sql))
                {
                    roleCmd.Parameters.AddWithValue("@username", username);
                    string userRole = roleCmd.ExecuteScalar()?.ToString();

                    if (userRole == null)
                    {
                        MessageBox.Show("Invalid username");
                        return;
                    }

                    if (type == "TA" && userRole == "Student")
                    {
                        // Check if the student is logged in as TA
                        string taCheckQuery = "SELECT COUNT(*) FROM dbo.TA WHERE TID = @username";
                        using (SqlCommand taCheckCmd = new SqlCommand(taCheckQuery, sql))
                        {
                            taCheckCmd.Parameters.AddWithValue("@username", username);
                            int taCount = (int)taCheckCmd.ExecuteScalar();

                            if (taCount == 0)
                            {
                                MessageBox.Show("You are not assigned as a TA.");
                                return;
                            }
                        }
                    }
                    else if (type == "LD" && userRole == "Student")
                    {
                        // Check if the student is logged in as LD
                        string ldCheckQuery = "SELECT COUNT(*) FROM dbo.LD WHERE LID = @username";
                        using (SqlCommand ldCheckCmd = new SqlCommand(ldCheckQuery, sql))
                        {
                            ldCheckCmd.Parameters.AddWithValue("@username", username);
                            int ldCount = (int)ldCheckCmd.ExecuteScalar();

                            if (ldCount == 0)
                            {
                                MessageBox.Show("You are not assigned as an LD.");
                                return;
                            }
                        }
                    }

                    // Login based on the type
                    string loginQuery = "SELECT * FROM dbo.Student1 WHERE StudentID = @username AND StudentPassword = @password";
                    if (type == "TA")
                    {
                        loginQuery = "SELECT * FROM dbo.TA WHERE TID = @username AND TPassword = @password";
                    }
                    else if (type == "LD")
                    {
                        loginQuery = "SELECT * FROM dbo.LD WHERE LID = @username AND LPassword = @password";
                    }

                    using (SqlCommand cmd = new SqlCommand(loginQuery, sql))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                // If there are rows, it means the user with the provided username and password exists
                                MessageBox.Show("Login successful");
                                Student_menu men = new Student_menu(username, password);
                                this.Visible = false;
                                men.Visible = true;
                            }
                            else
                            {
                                // No matching user found
                                MessageBox.Show("Invalid username or password");
                            }
                        }
                    }
                }
            }
        }

        private void useridbox_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string username = useridbox.Text.Trim().ToLower(); // Assuming you want to use lowercase
            string password = passwordbox.Text;
            string type = typebox.Text;

          
            string connectionString = "Data Source=DESKTOP-1FALRBA\\SQLEXPRESS;" +
                                      "Initial Catalog=i212569_i212971_B_project;Integrated Security=True";

            using (SqlConnection sql = new SqlConnection(connectionString))
            {
                sql.Open();

                string roleQuery = "SELECT role FROM dbo.Person WHERE PersonID = @username";
                using (SqlCommand roleCmd = new SqlCommand(roleQuery, sql))
                {
                    roleCmd.Parameters.AddWithValue("@username", username);
                    string userRole = roleCmd.ExecuteScalar()?.ToString();

                    if (userRole == null)
                    {
                        MessageBox.Show("Invalid username");
                        return;
                    }

                    if (type == "TA" && userRole == "Student")
                    {
                        // Check if the student is logged in as TA
                        string taCheckQuery = "SELECT COUNT(*) FROM dbo.TA WHERE TID = @username";
                        using (SqlCommand taCheckCmd = new SqlCommand(taCheckQuery, sql))
                        {
                            taCheckCmd.Parameters.AddWithValue("@username", username);
                            int taCount = (int)taCheckCmd.ExecuteScalar();

                            if (taCount == 0)
                            {
                                MessageBox.Show("You are not assigned as a TA.");
                                return;
                            }
                        }
                    }
                    else if (type == "LD" && userRole == "Student")
                    {
                        // Check if the student is logged in as LD
                        string ldCheckQuery = "SELECT COUNT(*) FROM dbo.LD WHERE LID = @username";
                        using (SqlCommand ldCheckCmd = new SqlCommand(ldCheckQuery, sql))
                        {
                            ldCheckCmd.Parameters.AddWithValue("@username", username);
                            int ldCount = (int)ldCheckCmd.ExecuteScalar();

                            if (ldCount == 0)
                            {
                                MessageBox.Show("You are not assigned as an LD.");
                                return;
                            }
                        }
                    }

                    // Login based on the type
                    string loginQuery = "SELECT * FROM dbo.Student1 WHERE StudentID = @username AND StudentPassword = @password";
                    if (type == "TA")
                    {
                        loginQuery = "SELECT * FROM dbo.TA WHERE TID = @username AND TPassword = @password";
                    }
                    else if (type == "LD")
                    {
                        loginQuery = "SELECT * FROM dbo.LD WHERE LID = @username AND LPassword = @password";
                    }

                    using (SqlCommand cmd = new SqlCommand(loginQuery, sql))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                // If there are rows, it means the user with the provided username and password exists
                                MessageBox.Show("Login successful");
                                Student_menu men = new Student_menu(username, password);
                                this.Visible = false;
                                men.Visible = true;
                            }
                            else
                            {
                                // No matching user found
                                MessageBox.Show("Invalid username or password");
                            }
                        }
                    }
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
