﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class AdminCourseAllocation : Form
    {
        public AdminCourseAllocation()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AssigningCourse assigningCourse = new AssigningCourse();
            this.Visible = false;
            assigningCourse.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewingCourseAllocation viewingCourseAllocation = new ViewingCourseAllocation();
            this.Visible = false;
            viewingCourseAllocation.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            adminMenu adminMenu = new adminMenu();
            this.Visible = false;
            adminMenu.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeallocatingCourse deallocatingCourse = new DeallocatingCourse();
            this.Visible=false;
            deallocatingCourse.Visible=true;  
        }
    }
}
