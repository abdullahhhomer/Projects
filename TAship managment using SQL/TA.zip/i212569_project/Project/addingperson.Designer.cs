﻿namespace Project
{
    partial class addingperson
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addingperson));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            personidbox = new TextBox();
            button1 = new Button();
            button2 = new Button();
            comboBox1 = new ComboBox();
            button3 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(230, 54);
            label1.Name = "label1";
            label1.Size = new Size(278, 28);
            label1.TabIndex = 0;
            label1.Text = "Enter the following Credentials";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(174, 120);
            label2.Name = "label2";
            label2.Size = new Size(94, 28);
            label2.TabIndex = 1;
            label2.Text = "Person ID";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Heading", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(193, 180);
            label3.Name = "label3";
            label3.Size = new Size(49, 28);
            label3.TabIndex = 2;
            label3.Text = "Role";
            // 
            // personidbox
            // 
            personidbox.Location = new Point(303, 120);
            personidbox.Name = "personidbox";
            personidbox.Size = new Size(159, 23);
            personidbox.TabIndex = 3;
            // 
            // button1
            // 
            button1.Location = new Point(342, 219);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 5;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(133, 289);
            button2.Name = "button2";
            button2.Size = new Size(95, 23);
            button2.TabIndex = 6;
            button2.Text = "Back to List";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Admin", "Faculty", "Student" });
            comboBox1.Location = new Point(303, 180);
            comboBox1.MaxDropDownItems = 3;
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(159, 23);
            comboBox1.TabIndex = 7;
            // 
            // button3
            // 
            button3.Location = new Point(326, 258);
            button3.Name = "button3";
            button3.Size = new Size(115, 23);
            button3.TabIndex = 8;
            button3.Text = "View Persons";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // addingperson
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button3);
            Controls.Add(comboBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(personidbox);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "addingperson";
            Text = "Adding Person";
            Load += addingperson_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox personidbox;
        private Button button1;
        private Button button2;
        private ComboBox comboBox1;
        private Button button3;
    }
}