use i212569_i212971_B_project
	create table Person(PersonID varchar(10)primary key,role varchar(10));
	create table Admin1(AdminID varchar(10) references Person(PersonID) primary key,adminName varchar(50),adminPassword varchar(100),adminEmail varchar(50));
	create table Faculty1(FacultyID varchar(10) references Person(PersonID)primary key,FacultyName varchar(50),FacultyPassword varchar(100),FacultyEmail varchar(50));
	create table Student1(StudentID varchar(10) references Person(PersonID)primary key,StudentName varchar(50),StudentPassword varchar(100),StudentEmail varchar(50));
	create table Course1(CourseID varchar(10) primary key,courseName varchar(50),Section varchar(2),adminid varchar(10) references Admin1(adminID));
	create table Payment1(paymentID varchar(10)primary key,payment int,paymentDate date,
						  adminid varchar(10) references Admin1(adminID),studentid varchar(10) references Student1(studentID) );
	create table Task1(taskID varchar(10)primary key,TaskName varchar(20),description varchar(500),DeadLine date,
					   Status bit,feedbackText varchar(1000),feedbackDate date,
					   facultyId varchar(10)references Faculty1(facultyID),StudentID varchar(10)references Student1(studentID),
					   courseID varchar(10)references Course1(CourseID));
	create table TA(TID varchar(10)references Student1(StudentID),NumberOfStudents int,from1 date,to1 date);
	create table LD(LID varchar(10)references Student1(StudentID),NumberOfStudents int,from1 date,to1 date);
	create table CourseAllocated(courseId1 varchar(10) references Course1(courseID),studentId1 varchar(10)references Student1(studentID));

insert into Person values('P101','Admin');
insert into Admin1 values('P101','Amir Rehman','asd123','amirrehman@nu.edu.pk');

select * from LD

select * from Person
select * from Faculty1
select * from Student1
select * from Course1
select * from Admin1


-- Inserting Students
INSERT INTO Person(PersonID, role) VALUES ('s101', 'Student');
INSERT INTO Person(PersonID, role) VALUES ('s102', 'Student');

-- Inserting TA and LD
INSERT INTO TA (TID, NumberOfStudents, from1, to1) VALUES ('S101', 5, '2023-01-01', '2023-12-31');
INSERT INTO LD (LID, NumberOfStudents, from1, to1) VALUES ('S102', 3, '2023-01-01', '2023-12-31');
INSERT INTO Student1 (StudentID, StudentName, StudentPassword, StudentEmail)
VALUES ('s101', 'Student1Name', 'abcd123', 'student1@example.com');

INSERT INTO Student1 (StudentID, StudentName, StudentPassword, StudentEmail)
VALUES ('s102', 'Student2Name', 'abcd123', 'student2@example.com');



-- Assigning Tasks
-- Assuming you have a task for TA and another for LD
INSERT INTO Task1 (taskID, TaskName, description, DeadLine, Status, feedbackText, feedbackDate, facultyId, StudentID, courseID)
VALUES ('T101', 'Teaching Task', 'Help in conducting classes', '2023-02-28', 0, NULL, NULL, NULL, 's102', NULL);

INSERT INTO Task1 (taskID, TaskName, description, DeadLine, Status, feedbackText, feedbackDate, facultyId, StudentID, courseID)
VALUES ('T102', 'Learning Task', 'Assist in student development programs', '2023-03-15', 0, NULL, NULL, NULL, 's102', NULL);

select* from Task1;